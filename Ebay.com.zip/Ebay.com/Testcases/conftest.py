import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait


@pytest.fixture
def setup():
    driver=webdriver.Chrome()
    driver.maximize_window()
    driver.get('https://www.ebay.com/')

    driver.implicitly_wait(5)

    return driver