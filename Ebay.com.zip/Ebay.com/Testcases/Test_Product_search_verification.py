import time

from selenium.webdriver.common.by import By

from Page_Objects.Page_object_for_search_product import ebay_product_search
from Utilities.Logger import LogGenerator
import allure
from allure_commons.types import AttachmentType


class Test_product_verify:
    log=LogGenerator.loggen()

    @allure.severity(allure.severity_level.NORMAL)
    @allure.link("https://www.ebay.com/")
    @allure.title(" Page Title Test Case")
    @allure.issue("ABC123")
    @allure.story(" This is story#1")


    # called webdriver and Page objects in test_product_categories

    def test_product_search(self,setup):

        self.log.info( '"test_product_categories" testcase execution start' )
        self.driver=setup
        self.lp=ebay_product_search(self.driver)
        self.log.info(' Type string "Macbook" ')
        # type 'macbook' in search box
        self.lp.search_method('Macbook')

        # select categories from dropdownbox
        self.log.info(' select categories "Computers/Tablets & Networking" ')
        self.lp.categories_dropdown('Computers/Tablets & Networking')

        # click on search button
        self.log.info(' Click on search button ')

        self.lp.click_on_search_button()

        b=self.driver.find_element(By.XPATH,'//*[@id="gh-ac"]').text
        print(b)
        a=self.driver.find_element(*self.lp.product_veri_xpath).text
        print(a)

        # apply validation base on serach string are present in first output element if it is present
        # then assertion is True otherwise assertion is false
        # eg. search string is 'Macbook' this string is present in product tital or not
        if 'Macbook' in a:
            self.log.info(' Take a screenshots ')
            self.driver.save_screenshot('F:\\Ebay.com\\ScreenShots\\test_product_categories.png')
            allure.attach(self.driver.get_screenshot_as_png(), name="test_product_categories",
                          attachment_type=AttachmentType.PNG)

            assert True
        else:
            assert False







