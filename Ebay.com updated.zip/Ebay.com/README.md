
# Ebay 

1) Validate test scenario To  Access a Product via category after applying multiple filters.




## Installation

Install Python

1.Go tolink https://www.python.org/downloads/
2.Click on Download
3.Once the python.exe file is downloaded double click on it
4.Python Installer will open Click on ‘add python.exe to path’ checkboxand click on install now .
And refer this path below install now C:\Users\Tushar\AppData\Local\Programs\Python\Python311\

Type "where python " and "python –version" in cmd.You should get this output in cmd. If output is getting then your python is successfully install

Installation Pycharm

1.Go to Url: ‘https://www.jetbrains.com/pycharm/download/’

2.Download PyCharm Community Edition, click on download
3.Double click on pychram.exe file

4.Installer will open and click on next

5.Choose installation location or keep it as default location in C: drive and click on next .

6.Click on all check boxes which are related to pycharm ide support to other application you system

7.Keep default folder jetbrains and click on install button

8. installation is done.
Pycharm setting for Pytest project

1.Open pycharm and click on new project

2.Keep all setting as is it and click on create

3.New project will open in pycharmand wait till indexing process below to completed

4.Go to settings(ctrl+shift+S)

5.Search interpreter in setting and click on + button

6.Available  packages window will open and install below libraries
a.Selenium

b.Pytest

c.Pytest-html

d.Pytest-xdist

e.Allure-Pytest

f.openpyxl

7.Open setting and search terminal and select shell path” C:\WINDOWS\system32\cmd.exe”
Click on apply

8.Open setting and search python integrated tools and select pytest and default test runner.

9.Run your testcases in python













    
## Running Tests

To run tests, run the following command

```bash
  Pytest -v -s "file loacation"
```
To run all testcases at a time then run following command in terminal

```bash
  Pytest -v -s 
```
To run all testcases at a time and you want to genrate allure report then run following command in terminal. run 1st command and then 2nd command
(in folder path please enter path and then run)

```bash
  Pytest -v -s --alluredir="Report folder path"

allure serve " report folder path"

```









Yo can run this test cases by clicking on ".bat "file which are store in "Run.bat" folder
## Documentation

[Documentation](https://github.com/Sangambpawar/Ebay_task.git)


## 🔗 Links
https://github.com/Sangambpawar/Ebay_task.git


https://drive.google.com/file/d/1TsW196Btm7EPco_4ngTA6QjKiUCQES4z/view?usp=sharing
## Acknowledgements

 - 


## How build my framework

- Create new Project & Install Required Packages/plugins

-  Selenium : Selenium Libraries

    Pytest : Python framework

    Pytest-html: PyTest HTML Reports

    Pytest-xdist : Run Tests Parallel

    Openpyxl : Ms Excel Support

    allure-pytest : to generate allure reports

 

- Create folder structure
- Then create conftest file to called driver
-   Then write a test cases
-   Then I create ".bat file" for you ". Bat" file is used to run the testcases
-   Double click on bat file





## NOTE

Here are some related projects

when you execute test cases if 
"NoSuchElementException" occurs then re-run test 
cases again because of this exception is due to 
inproper network connection or element not found by 
interpreter that’s why this exceptions are occurs if you 
want to proper result then you have re-run test cases 
until whole test are run automatically.

Generally "NoSuchElementException "occurs in first test 
case because there is need to scroll window that’s
why some time it does not work properly so run test 
cases again and again.

I also mention in script What  bases assertion are 
apply.


## What basis assertion is applied
1) for testcase "test_product_categories"


    For validating condition based on filter selected and filter applied are same or Not.
     test case validation by using  how many filter are selected and how many filter are applied on webpage this condition are used to validate the testcase.

 2) For Testcase "test_product_search"
    apply validation base on serach string are present in first output element if it is presentthen assertion is True otherwise assertion is false
eg. search string is 'Macbook' this string is present in product tital or not





## Support

For support, email sangambpawar1@gmail.com 

If any issue are occurs to run the test cases then you 
can contact me - 9265743162 sangam pawar


