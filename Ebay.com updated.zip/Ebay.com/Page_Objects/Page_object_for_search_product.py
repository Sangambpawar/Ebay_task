from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select



class ebay_product_search():
    search_xpath=By.XPATH,'//*[@id="gh-ac"]'
    categories_xpath_dropdown=By.XPATH,'//*[@id="gh-cat"]'
    search_button_xpath=By.XPATH,'//*[@id="gh-btn"]'
    product_veri_xpath=By.XPATH,'//*[@id="item4d669d6f06"]/div/div[2]/a/div/span/span'

    def __init__(self,driver):
        self.driver=driver

    def search_method(self,name):
        self.driver.find_element(*ebay_product_search.search_xpath).send_keys(name)

    def categories_dropdown(self,dropdown):
        a=Select(self.driver.find_element(*ebay_product_search.categories_xpath_dropdown))
        a.select_by_visible_text(dropdown)
    def click_on_search_button(self):
        self.driver.find_element(*ebay_product_search.search_button_xpath).click()




