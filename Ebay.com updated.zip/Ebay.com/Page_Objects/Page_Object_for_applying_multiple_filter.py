from selenium.webdriver.common.by import By


class ebay():
    search_xpath=(By.XPATH,'//*[@id="gh-ac"]')
    Shop_by_categories_Xpath= By.XPATH,'//*[@id="gh-shop-a"]'
    cell_phone_and_accessories_xpath=By.XPATH,'//*[@id="gh-sbc"]/tbody/tr/td[1]/ul[2]/li[4]/a'
    cell_phone_and_smartphones_xpath=By.XPATH,'//*[@id="s0-17-12_2-0-1[0]-0-0"]/ul/li[3]/a'
    cell_phone_and_smartphones_append_xpath=By.XPATH,'//*[@id="s0-17-12_2-0-1[0]-0-0"]/ul/li[2]/strong'
    all_filter_xpath=By.XPATH,'/html/body/div[4]/div[4]/div[3]/section[2]/section/ul[1]/li[9]/button'
    condition_xpath=By.XPATH,'//*[@id="c3-mainPanel-condition"]/span'
    New_xpath=By.XPATH,'//*[@id="c3-subPanel-LH_ItemCondition_New_cbx"]'
    price_Xpath=(By.XPATH,'//*[@id="c3-mainPanel-price"]')
    price_xpth_entervalue_1=(By.XPATH,'//*[@id="c3-subPanel-_x-price-textrange"]/div/div[1]/div/input')
    price_xpth_entervalue_2 = (By.XPATH, '//*[@id="c3-subPanel-_x-price-textrange"]/div/div[2]/div/input')
    Click_item_location_xpath=(By.XPATH,'//*[@id="c3-mainPanel-location"]/span')
    Click_item_location_north_america_xpath=(By.XPATH,'//*[@id="c3-subPanel-location_North%20America"]/span/span/input')
    click_apply_xpath=(By.XPATH,'//*[@id="x-overlay__form"]/div[3]/div[2]/button')
    status=(By.XPATH,'//*[@id="s0-28_1-9-0-1[0]-0-0-6-8-4[0]-flyout"]/button/span')
    validate_xpath=By.XPATH,'//*[@id="innerlayer"]/button/span[1]'

    def __init__(self,driver):
        self.driver=driver

    def Shop_by_categories(self):
        self.driver.find_element(*ebay.Shop_by_categories_Xpath).click()
    def cell_phone_and_accessories_(self):
        self.driver.find_element(*ebay.cell_phone_and_accessories_xpath).click()
    def cell_phone_and_smartphones_(self):
        self.driver.find_element(*ebay.cell_phone_and_smartphones_xpath).click()
    def all_filter_(self):
        self.driver.find_element(*ebay.all_filter_xpath).click()
    def condition_(self):
        self.driver.find_element(*ebay.condition_xpath).click()
    def select_new(self):
        self.driver.find_element(*ebay.New_xpath).click()
    def click_on_price_(self):
        self.driver.find_element(*ebay.price_Xpath).click()
    def price_entervalue_1(self,price):
        self.driver.find_element(*ebay.price_xpth_entervalue_1).send_keys(price)

    def price_entervalue_2(self,price):
        self.driver.find_element(*ebay.price_xpth_entervalue_2).send_keys(price)
    def Click_item_location_(self):
        self.driver.find_element(*ebay.Click_item_location_xpath).click()

    def Click_item_location_North_America(self):
        self.driver.find_element(*ebay.Click_item_location_north_america_xpath).click()
    def click_apply(self):
        self.driver.find_element(*ebay.click_apply_xpath).click()

    def status_for_filter(self):
        self.driver.find_element(*ebay.status)
    def validate_total_apply_filter(self):
        self.driver.find_element(*ebay.validate_xpath)



















