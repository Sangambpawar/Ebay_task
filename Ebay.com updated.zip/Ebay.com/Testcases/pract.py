dict1={1:'a',2:'b',3:'c',4:'d'}
list1=[1,2]
dict2={k:dict1[k] for k in list1}
print(dict2)

