import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from Page_Objects.Page_Object_for_applying_multiple_filter import ebay
from Utilities.Logger1 import LogGenerator
import allure
from allure_commons.types import AttachmentType


class Test_validate_product:
    log=LogGenerator.loggen()
    # called webdriver and Page objects in test_product_categories

    def test_product_categories(self,setup):

        self.driver=setup
        self.lp=ebay(self.driver)
        self.log.info('Start testcase excecution of test case "test_product_categories"')

        # object for explicit wait
        self.wait=WebDriverWait(self.driver,10)

        # click on Shop_by_categories
        self.log.info('Click on shop by categories')
        self.lp.Shop_by_categories()

        # click on cells and accessories
        self.log.info('click on cells and accessories')
        self.lp.cell_phone_and_accessories_()

        # click cell phones and smartphones
        self.log.info('Click on cell phones and smartphone')
        self.lp.cell_phone_and_smartphones_()

        # for display all filter we scroll down web page
        self.log.info('Scroll down web page and select all filter')
        a=self.driver.find_element(By.XPATH,'/html/body/div[4]/div[4]/div[3]/section[2]/section/ul[1]/li[9]/button')
        self.driver.execute_script("arguments[0].scrollIntoView();",a)
        # explicit wait are used
        self.wait.until(expected_conditions.element_to_be_clickable(self.lp.all_filter_xpath))
        # click on all filters
        self.lp.all_filter_()

        # scroll down for search condition
        self.log.info('Scroll down web page and select condition')


        b=self.driver.find_element(By.XPATH,'//*[@id="c3-mainPanel-condition"]/span')
        self.driver.execute_script("arguments[0].scrollIntoView();", b)
        self.wait.until(expected_conditions.element_to_be_clickable(self.lp.condition_xpath))

        # add filters
        self.lp.condition_()

        rollback_new=self.driver.find_element(By.XPATH,'//*[@id="c3-subPanel-LH_ItemCondition_New_cbx"]')
        self.driver.execute_script("arguments[0].scrollIntoView();", rollback_new)

        # click on new
        self.wait.until(expected_conditions.element_to_be_clickable(self.lp.condition_xpath))
        self.log.info('select condition new')

        self.lp.select_new()

        # click on price
        self.log.info('Scroll down web page and select filter price')

        rollback_sell_price = self.driver.find_element(By.XPATH, '//*[@id="c3-mainPanel-price"]')
        self.driver.execute_script("arguments[0].scrollIntoView();", rollback_sell_price)
        self.lp.click_on_price_()

        # Enter starting price in ($)
        self.log.info('Scroll down web page and select starting price and enter price value ')

        rollback_enter_price = self.driver.find_element(By.XPATH, '//*[@id="c3-subPanel-_x-price-textrange"]/div/div[1]/div/input')
        self.driver.execute_script("arguments[0].scrollIntoView();", rollback_enter_price)
        self.lp.price_entervalue_1(10)
        rollback_enter_price = self.driver.find_element(By.XPATH,'//*[@id="c3-subPanel-_x-price-textrange"]/div/div[1]/div/input')

        # Enter last price in  ($)
        self.log.info('enter target price')

        self.driver.execute_script("arguments[0].scrollIntoView();", rollback_enter_price)
        self.lp.price_entervalue_2(100)



        # select location filter
        self.log.info('select location filter')
        self.lp.Click_item_location_()

        # select us location
        self.log.info('select location North America')
        self.lp.Click_item_location_North_America()

        # click on apply button to apply filter

        # It will display no of filter selected

        filter_apply=(self.driver.find_element(*self.lp.validate_xpath).text)
        print(filter_apply)
        self.log.info('Click on apply button')

        self.lp.click_apply()

        time.sleep(5)  # hard time
        # It will display no of actually filter applied

        filter=(self.driver.find_element(*self.lp.status).text)

        #screenshot
        self.log.info('Take screenshot')

        self.driver.save_screenshot('F:\\Ebay.com\\ScreenShots\\filter_apply.png')
        allure.attach(self.driver.get_screenshot_as_png(), name="test_product_categories",
                      attachment_type=AttachmentType.PNG)
        print(filter)

        # for validating condition based on filter selected and filter applied are same or Not
        # test case validation by using how many filter are selected and how many filter are aplly
        # on webpage this condition are used to validate the testcase.
        if filter_apply[1] == filter[0]:

            assert True
        else:
            assert False













